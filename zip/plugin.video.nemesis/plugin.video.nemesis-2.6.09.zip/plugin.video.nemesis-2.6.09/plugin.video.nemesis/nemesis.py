# -*- coding: utf-8 -*-
"""
	Nemesis Add-on
"""

from sys import argv
from modules.router import routing
routing(argv[2])
